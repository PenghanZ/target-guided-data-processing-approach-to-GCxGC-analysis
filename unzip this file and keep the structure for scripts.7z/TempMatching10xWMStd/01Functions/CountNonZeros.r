
CountNonZeros <- function(inputVectors){


Counts <- length(which(inputVectors > 0))


return(Counts)
}