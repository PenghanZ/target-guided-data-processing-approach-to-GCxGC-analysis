


AllPeakLabelTIC <- function(FolderRoute, modulation_time, XSlice, XSignal){


Function1 <- paste0(FolderRoute,"/01Functions/PkLabelTIC2.r")
source(Function1)

RawDataFolder <- paste0(FolderRoute,"/02RawGCxGCMSData")


FileList <- list.files(RawDataFolder)

for(i in 1:length(FileList))
{
CurrentFile <- paste0(RawDataFolder,"/",FileList[i])
PkLabeledTIC <- PkLabelTIC2(CurrentFile,modulation_time, XSlice, XSignal)



SavingRoute <- paste0(FolderRoute,"/04LabeledPeakTIC")
FileName <- gsub(".cdf", "", FileList[i])
WriteFile <- paste0(SavingRoute,"/",FileName,".RData")
save(PkLabeledTIC, file = WriteFile)
}
}