

AttributeMatrix <- function(Attribute,modulation_time,filename){

library(ncdf4)
data <- nc_open( filename, write=FALSE, readunlim=TRUE, verbose=FALSE, auto_GMT=TRUE, suppress_dimvals=FALSE )


scan_acquisition_time <- ncvar_get(data, varid = "scan_acquisition_time")
MS_start_time <- min(scan_acquisition_time)
MS_end_time <- max(scan_acquisition_time)

total_resolution <- length(Attribute)
scan_duration <- ncvar_get(data, varid = "scan_duration")
second_dimension_resolution <- modulation_time / scan_duration[1]
first_dimension_resolution <- total_resolution / second_dimension_resolution


Attribute_matrix <- matrix(Attribute,nrow = second_dimension_resolution, ncol = first_dimension_resolution)



Attribute_matrix_updown <- Attribute_matrix[dim(Attribute_matrix)[1]:1,]


first_dimension_axis <- matrix(nrow = 1, ncol = first_dimension_resolution)
for(i in 1:first_dimension_resolution) {
first_dimension_axis[1,i]= MS_start_time + (i-1)* modulation_time
}


second_dimension_axis <- matrix(nrow = second_dimension_resolution, ncol = 1)
for(j in 1:second_dimension_resolution) {
second_dimension_axis[j,1]= 0 + (j-1)*0.005
}
second_dimension_axis <- as.matrix(second_dimension_axis[dim(second_dimension_axis)[1]:1,])

rownames(Attribute_matrix_updown) <- second_dimension_axis
colnames(Attribute_matrix_updown) <- first_dimension_axis

return(Attribute_matrix_updown)   #

}
