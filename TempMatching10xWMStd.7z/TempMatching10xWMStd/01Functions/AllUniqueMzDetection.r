

AllUniqueMzDetection <- function(FolderRoute, LibraryName, MzNumThrasholding){



library(ncdf4)
library(ggplot2)
library(ChemmineR)
library(xlsx)



RawDataFolder <- paste0(FolderRoute,"/02RawGCxGCMSData")
FileList <- list.files(RawDataFolder)


Function12 <- paste0(FolderRoute,"/01Functions/CountNonZeros.r")   
source(Function12)

for(FileNameDot in FileList){

FileName <- gsub(".cdf", "", FileNameDot)
AllAnnotationsName <- paste0(FolderRoute,"/05AnnotationResult/",FileName,".xlsx")
AllAnnotations <- read.xlsx(AllAnnotationsName, 1,stringsAsFactors = F)
AllAnnotations <- AllAnnotations[-1,]
AllAnnotatedTempIndex <- unique(AllAnnotations[,"TemplateIndex"])

for(AnnotatedTempIndex in AllAnnotatedTempIndex){

print(AnnotatedTempIndex)

ApexResultAllMzFileRoute <- paste0(FolderRoute,"/06ApexResultAllMz")
TempIndex <- as.character(AnnotatedTempIndex)
ApexResultAllMzFileName <- paste0(ApexResultAllMzFileRoute,"/",FileName,"TempIndex",TempIndex,".RData")
load(ApexResultAllMzFileName)


ApexSum <- apply(ApexResultAllMz,c(1,2),FUN=CountNonZeros)
BinaryApexSum <- ApexSum
BinaryApexSum[which(BinaryApexSum > 0)] <- 1

Function13 <- paste0(FolderRoute,"/01Functions/BWConnLabel.r")
source(Function13)
PkLabeledApexSum <- BWConnLabel(BinaryApexSum)
rownames(PkLabeledApexSum) <- rownames(BinaryApexSum)
colnames(PkLabeledApexSum) <- colnames(BinaryApexSum)



FilterredApexSum <- ApexSum
for(ApexRegionIndex in seq(max(PkLabeledApexSum))){  

ApexRegionTotalMzBum <- sum(ApexSum[which(PkLabeledApexSum == ApexRegionIndex)])

if(ApexRegionTotalMzBum < MzNumThrasholding){
FilterredApexSum[which(PkLabeledApexSum == ApexRegionIndex)] <- 0
}

}

FilterredPkLabeledApexSum <- PkLabeledApexSum
FilterredPkLabeledApexSum[which(FilterredApexSum == 0)] <- 0
SubPkApexAll <- unique(FilterredPkLabeledApexSum[which(FilterredPkLabeledApexSum > 0)])


SubPkMzGrouping <- list()

for(EachSubPkApexsIndex in SubPkApexAll){



SubPkApexPixelIndexs <- which(FilterredPkLabeledApexSum == EachSubPkApexsIndex, arr.ind = TRUE)
SubPkApexPixelIndexsLength <- length(SubPkApexPixelIndexs)/2
SubPkApexPixelMzMatrix <- matrix(,nrow = SubPkApexPixelIndexsLength,ncol = dim(ApexResultAllMz)[3])


for(EachSubPkApexPixel in seq(SubPkApexPixelIndexsLength)){

PixelRowCol <- SubPkApexPixelIndexs[EachSubPkApexPixel,]
PixelMzs <- ApexResultAllMz[PixelRowCol[1],PixelRowCol[2],]
SubPkApexPixelMzMatrix[EachSubPkApexPixel,] <- PixelMzs

}

SubPkIndex <- which(SubPkApexAll == EachSubPkApexsIndex)
SubPkMzGrouping [[SubPkIndex]] <- unique(as.vector(SubPkApexPixelMzMatrix))
SubPkName <- paste0(FileName,"TempIndex",TempIndex,"SubPk",EachSubPkApexsIndex)
names(SubPkMzGrouping)[SubPkIndex] <- SubPkName

}



MSLibName <- paste0(FolderRoute, "/00Library/", LibraryName)
PkTemplate <- read.SDFset(MSLibName)

Function4 <- paste0(FolderRoute,"/01Functions/getTemplateMS.r")
source(Function4)
TemplateMS <- getTemplateMS(FolderRoute, LibraryName, as.numeric(AnnotatedTempIndex))

seqTemplateMS <- t(apply(TemplateMS,1,sort,decreasing = TRUE))
seqTemplateMz <- colnames(seqTemplateMS)

 
UniqueTestResult <- matrix(0,nrow = length(SubPkApexAll), ncol = length(seqTemplateMz))
rownames(UniqueTestResult) <- names(SubPkMzGrouping)
colnames(UniqueTestResult) <- seqTemplateMz

for(eachSubPkMzGrouping in names(SubPkMzGrouping)){


testingSubPkMz <- SubPkMzGrouping[[eachSubPkMzGrouping]]

for(eachTemplateMZ in seqTemplateMz){


if(as.numeric(eachTemplateMZ) %in% testingSubPkMz){
UniqueTestResult[eachSubPkMzGrouping,eachTemplateMZ] <- 1
}

}

}

UniqueTestResultSum <- apply(UniqueTestResult,2,FUN=sum)
FilteredUniqueTestResultSum <- UniqueTestResult[,which(UniqueTestResultSum == 1),drop=FALSE]


SavingRoute <- paste0(FolderRoute,"/07UniqueMz")
FileName <- gsub(".cdf", "", FileNameDot)
TempIndex <- as.character(AnnotatedTempIndex)
WriteFile <- paste0(SavingRoute,"/",FileName,"TempIndex",TempIndex,".RData")
save(FilteredUniqueTestResultSum, file = WriteFile)

}

}

}