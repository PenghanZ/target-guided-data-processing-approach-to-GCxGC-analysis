


AttributeMatrixPlot <- function(AttributeMatrix, modulation_time, filename){

library(ncdf4)
data <- nc_open( filename, write=FALSE, readunlim=TRUE, verbose=FALSE, auto_GMT=TRUE, suppress_dimvals=FALSE )

total_resolution <- length(AttributeMatrix)
scan_duration <- ncvar_get(data, varid = "scan_duration")
second_dimension_resolution <- modulation_time / scan_duration[1]
first_dimension_resolution <- total_resolution / second_dimension_resolution

first_dimension_axis <- as.numeric(colnames(AttributeMatrix)) 
second_dimension_axis <- as.numeric(rownames(AttributeMatrix)) 



GC1d <- vector(mode = "numeric", length = total_resolution)
GC2d <- vector(mode = "numeric", length = total_resolution)
Intensity <- vector(mode = "numeric", length = total_resolution)

for(i in 1:first_dimension_resolution) {
for(j in 1:second_dimension_resolution) {


Intensity[(i-1)*second_dimension_resolution+j] = AttributeMatrix[j,i]


GC1d[(i-1)*second_dimension_resolution+j] = first_dimension_axis[i]


GC2d[(i-1)*second_dimension_resolution+j] = second_dimension_axis[j]

}
}
RootedIntensity <- Intensity^(1/3) 
ColormapDataFrame <- data.frame(GC1d, GC2d, RootedIntensity)



library(ggplot2)
ggplot(ColormapDataFrame, aes(GC1d, GC2d)) + geom_raster(aes(fill = RootedIntensity))

}